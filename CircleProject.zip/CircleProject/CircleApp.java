package com.gmail.cyrusmahle24; 

public class CircleApp{

public static void main(String[] args)

 Circle object = new Circle(10,2,1);
 Circle object = new Circle();

 object.getX();
 object.getY();
 object.getRadius();
 object.calculateArea();
 object.calculateCircumference();
 object.calculateDiameter();

}